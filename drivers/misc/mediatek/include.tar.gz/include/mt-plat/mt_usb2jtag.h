#ifndef __MT_USB2JTAG_H_
#define __MT_USB2JTAG_H_
int mt_usb2jtag_resume(void);
unsigned int usb2jtag_mode(void);
#endif
